export default function UsersPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">مدیریت کاربران</h1>
      <p>اینجا می‌توانید کاربران را مشاهده، اضافه یا ویرایش کنید.</p>
    </div>
  );
}
