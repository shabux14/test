export default function ServersPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">مدیریت سرورها</h1>
      <p>نمایش وضعیت سرورها، عملیات و تنظیمات مربوط به آن‌ها در این بخش انجام می‌شود.</p>
    </div>
  );
}

