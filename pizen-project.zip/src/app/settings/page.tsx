export default function SettingsPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">تنظیمات سامانه</h1>
      <p>در این بخش می‌توانید تنظیمات کلی سامانه را مدیریت کنید.</p>
    </div>
  );
}
